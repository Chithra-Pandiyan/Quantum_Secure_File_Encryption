const { useState, useEffect } = React;

const App = () => {
    const [currentPage, setCurrentPage] = useState('home');
    const [isLoggedIn, setIsLoggedIn] = useState(false);
    const [user, setUser] = useState(null);
    
    // Check if user is already logged in (from localStorage)
    useEffect(() => {
        const savedUser = localStorage.getItem('secureCryptCurrentUser');
        if (savedUser) {
            setUser(savedUser);
            setIsLoggedIn(true);
        }
    }, []);
    
    // Set active page based on URL hash or default to home
    useEffect(() => {
        const hash = window.location.hash.substring(1);
        if (hash && ['home', 'encrypt', 'decrypt', 'about'].includes(hash)) {
            setCurrentPage(hash);
        }
    }, []);
    
    // Update URL hash when page changes
    useEffect(() => {
        window.location.hash = currentPage;
    }, [currentPage]);
    
    const handleLogin = (username) => {
        setUser(username);
        setIsLoggedIn(true);
        localStorage.setItem('secureCryptCurrentUser', username);
    };
    
    const handleLogout = () => {
        setUser(null);
        setIsLoggedIn(false);
        localStorage.removeItem('secureCryptCurrentUser');
        setCurrentPage('home');
    };
    
    if (!isLoggedIn) {
        return React.createElement(AuthPage, { onLogin: handleLogin });
    }
    
    return React.createElement('div', { className: 'app' },
        React.createElement(Header, { 
            currentPage: currentPage, 
            setCurrentPage: setCurrentPage, 
            user: user,
            onLogout: handleLogout
        }),
        React.createElement('main', null,
            currentPage === 'home' && React.createElement(HomePage, { setCurrentPage: setCurrentPage }),
            currentPage === 'encrypt' && React.createElement(EncryptionTool, { setCurrentPage: setCurrentPage }),
            currentPage === 'decrypt' && React.createElement(DecryptionTool, { setCurrentPage: setCurrentPage }),
            currentPage === 'about' && React.createElement(AboutPage, { setCurrentPage: setCurrentPage })
        ),
        React.createElement(Footer)
    );
};

// Footer Component
const Footer = () => {
    return (
        <footer>
            <div className="container">
                <div className="footer-content">
                    <div className="logo">
                        <i className="fas fa-shield-alt"></i>
                        <span>Secure File Encryption Tool</span>
                    </div>
                    
                    <div className="footer-links">
                        <a href="#">Privacy Policy</a>
                        <a href="#">Terms of Service</a>
                        <a href="#">Contact Us</a>
                    </div>
                    
                    <p className="copyright">
                        &copy; 2024 Secure File Encryption Tool. All rights reserved.
                    </p>
                </div>
            </div>
        </footer>
    );
};

// Render the App
ReactDOM.render(React.createElement(App), document.getElementById('root'));