const puppeteer = require('puppeteer');

(async () => {
  const url = 'http://127.0.0.1:3000';
  const username = 'auto_test_user';
  const password = 'Passw0rd!';

  const headful = process.env.HEADFUL === '1' || process.env.HEADFUL === 'true';
  const browser = await puppeteer.launch({ headless: !headful, args: ['--no-sandbox', '--disable-setuid-sandbox'] });
  const page = await browser.newPage();

  page.on('dialog', async (dialog) => {
    await dialog.accept();
  });

  try {
    // Wait for server to be available (retry loop)
    const waitForServer = async (timeoutMs = 20000, intervalMs = 500) => {
      const start = Date.now();
      while (Date.now() - start < timeoutMs) {
        try {
          const resp = await page.goto(url, { waitUntil: 'domcontentloaded', timeout: 3000 });
          if (resp && resp.ok()) return true;
        } catch (e) {
          // ignore and retry
        }
        await new Promise(r => setTimeout(r, intervalMs));
      }
      return false;
    };

    const up = await waitForServer(20000, 500);
    if (!up) {
      throw new Error('Server not reachable at ' + url);
    }
    await page.waitForSelector('#username', { visible: true, timeout: 5000 });

    // Switch to register form if needed
    const regLink = await page.$x("//a[contains(text(),'Register') or contains(text(),'Register here')]");
    if (regLink.length) {
      await regLink[0].click();
    }

    await page.waitForSelector('#confirmPassword', { visible: true, timeout: 5000 });

    // Fill registration
    await page.click('#username', { clickCount: 3 });
    await page.type('#username', username, { delay: 50 });
    await page.click('#password', { clickCount: 3 });
    await page.type('#password', password, { delay: 50 });
    await page.click('#confirmPassword', { clickCount: 3 });
    await page.type('#confirmPassword', password, { delay: 50 });

    // Submit registration
    await page.click('button.btn');

    // wait for registration alert handled by dialog handler
    await page.waitForTimeout(800);

    // Ensure we're on login form
    // Fill login
    await page.waitForSelector('#username', { visible: true, timeout: 5000 });
    await page.click('#username', { clickCount: 3 });
    await page.type('#username', username, { delay: 50 });
    await page.click('#password', { clickCount: 3 });
    await page.type('#password', password, { delay: 50 });

    // Submit login
    await page.click('button.btn');

    // Wait for header user display
    await page.waitForSelector('.user-info span', { visible: true, timeout: 7000 });
    const userText = await page.$eval('.user-info span', el => el.textContent.trim());

    if (userText === username) {
      console.log('LOGIN_SUCCESS');
      process.exit(0);
    } else {
      console.error('LOGIN_MISMATCH', userText);
      process.exit(2);
    }

  } catch (err) {
    console.error('TEST_ERROR', err.message || err);
    process.exit(1);
  } finally {
    try { await browser.close(); } catch (e) {}
  }
})();
