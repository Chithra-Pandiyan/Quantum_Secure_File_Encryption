const HomePage = ({ setCurrentPage }) => {
    return (
        <div className="page active">
            <section className="hero">
                <div className="container">
                    <h1>Secure File Encryption Tool</h1>
                    <p>Protect your sensitive files with modern cryptographic algorithms. Fast, secure, and easy to use.</p>
                    <div className="action-buttons">
                        <button className="btn btn-large" onClick={() => setCurrentPage('encrypt')}>
                            <i className="fas fa-lock"></i> Encrypt Files
                        </button>
                        <button className="btn btn-large btn-outline" onClick={() => setCurrentPage('decrypt')}>
                            <i className="fas fa-unlock"></i> Decrypt Files
                        </button>
                    </div>
                </div>
            </section>
            
            <div className="container">
                <section className="features">
                    <div className="feature-card">
                        <div className="feature-icon">
                            <i className="fas fa-shield-alt"></i>
                        </div>
                        <h3>Military-Grade Security</h3>
                        <p>Advanced AES-256-GCM and ChaCha20 encryption to keep your files safe from unauthorized access.</p>
                    </div>
                    
                    <div className="feature-card">
                        <div className="feature-icon">
                            <i className="fas fa-bolt"></i>
                        </div>
                        <h3>Lightning Fast</h3>
                        <p>Quick encryption and decryption processes that don't compromise on security.</p>
                    </div>
                    
                    <div className="feature-card">
                        <div className="feature-icon">
                            <i className="fas fa-file-archive"></i>
                        </div>
                        <h3>ZIP Support</h3>
                        <p>Encrypt multiple files into a single ZIP archive for easy sharing and storage.</p>
                    </div>
                </section>
            </div>
        </div>
    );
};