const { useState } = React;

const DecryptionTool = ({ setCurrentPage }) => {
    const [selectedFile, setSelectedFile] = useState(null);
    const [password, setPassword] = useState('');
    const [showPassword, setShowPassword] = useState(false);
    const [isProcessing, setIsProcessing] = useState(false);
    const [progress, setProgress] = useState(0);
    const [result, setResult] = useState(null);
    const [decryptedFiles, setDecryptedFiles] = useState([]);
    const [fileInfo, setFileInfo] = useState(null);
    const [algorithm, setAlgorithm] = useState('auto');
    
    const handleFileSelect = (e) => {
        const file = e.target.files[0];
        if (file) {
            setSelectedFile(file);
            setResult(null);
            setDecryptedFiles([]);
            
            // Read file to get encryption info
            const reader = new FileReader();
            reader.onload = async (event) => {
                try {
                    const zip = await JSZip.loadAsync(event.target.result);
                    const metadataFile = zip.file('_metadata.json');
                    
                    if (metadataFile) {
                        const metadata = JSON.parse(await metadataFile.async('text'));
                        setFileInfo(metadata);
                        setAlgorithm(metadata.algorithm);
                    } else {
                        setFileInfo(null);
                        setAlgorithm('auto');
                    }
                } catch (error) {
                    console.error('Error reading ZIP metadata:', error);
                    setFileInfo(null);
                    setAlgorithm('auto');
                }
            };
            reader.readAsArrayBuffer(file);
        }
    };
    
    const handleDragOver = (e) => {
        e.preventDefault();
        e.currentTarget.classList.add('dragover');
    };
    
    const handleDragLeave = (e) => {
        e.preventDefault();
        e.currentTarget.classList.remove('dragover');
    };
    
    const handleDrop = (e) => {
        e.preventDefault();
        e.currentTarget.classList.remove('dragover');
        
        const file = e.dataTransfer.files[0];
        if (file) {
            handleFileSelect({ target: { files: [file] } });
        }
    };
    
    const handleDecrypt = async () => {
        if (!selectedFile) {
            alert('Please select an encrypted ZIP file.');
            return;
        }
        
        if (!password) {
            alert('Please enter the decryption password.');
            return;
        }
        
        setIsProcessing(true);
        setProgress(0);
        setResult(null);
        setDecryptedFiles([]);
        
        try {
            setProgress(20);
            
            // Decrypt ZIP file
            const files = await CryptoUtils.decryptZip(selectedFile, password, algorithm === 'auto' ? null : algorithm);
            
            setProgress(80);
            
            setDecryptedFiles(files);
            setProgress(100);
            
            setResult({ 
                success: true, 
                message: `Files decrypted successfully! You can now download the original files.` 
            });
        } catch (error) {
            console.error('Decryption error:', error);
            let errorMessage = error.message;
            
            // Provide more specific error messages
            if (error.message.includes('incorrect password') || error.message.includes('authentication')) {
                errorMessage = 'Decryption failed: Incorrect password. Please check your password and try again.';
            } else if (error.message.includes('corrupted')) {
                errorMessage = 'Decryption failed: The file appears to be corrupted or modified.';
            } else if (error.message.includes('algorithm')) {
                errorMessage = 'Decryption failed: Unsupported encryption algorithm. Please try selecting a specific algorithm.';
            }
            
            setResult({ 
                success: false, 
                message: errorMessage 
            });
        } finally {
            setIsProcessing(false);
        }
    };
    
    const resetForm = () => {
        setSelectedFile(null);
        setPassword('');
        setResult(null);
        setDecryptedFiles([]);
        setFileInfo(null);
        setAlgorithm('auto');
        document.getElementById('decrypt-file-input').value = '';
    };
    
    const togglePasswordVisibility = () => {
        setShowPassword(!showPassword);
    };
    
    return (
        <div className="page active">
            <div className="container">
                <div className="tool-section">
                    <h2><i className="fas fa-unlock"></i> Decrypt Your Files</h2>
                    
                    <div 
                        className="file-upload-area"
                        onDragOver={handleDragOver}
                        onDragLeave={handleDragLeave}
                        onDrop={handleDrop}
                        onClick={() => document.getElementById('decrypt-file-input').click()}
                    >
                        <i className="fas fa-cloud-upload-alt"></i>
                        <h3>Drag & Drop your encrypted ZIP file here</h3>
                        <p>or click to browse</p>
                        <input 
                            type="file" 
                            id="decrypt-file-input" 
                            style={{ display: 'none' }} 
                            onChange={handleFileSelect}
                            accept=".zip"
                        />
                    </div>
                    
                    <div className={`file-info ${selectedFile ? 'active' : ''}`}>
                        <h4>Selected File:</h4>
                        <p><i className="fas fa-file-archive"></i> {selectedFile?.name} ({(selectedFile?.size / 1024 / 1024).toFixed(2)} MB)</p>
                        {fileInfo && (
                            <div style={{ marginTop: '0.5rem' }}>
                                <p><strong>Algorithm:</strong> {fileInfo.algorithm?.toUpperCase()}</p>
                                <p><strong>Files:</strong> {fileInfo.files?.length || 0} files</p>
                                <p><strong>Encrypted:</strong> {new Date(fileInfo.timestamp).toLocaleString()}</p>
                            </div>
                        )}
                    </div>
                    
                    {selectedFile && (
                        <div className="password-input">
                            <label htmlFor="decrypt-password">Decryption Password</label>
                            <div className="password-input-container">
                                <input 
                                    type={showPassword ? "text" : "password"} 
                                    id="decrypt-password" 
                                    className="form-control" 
                                    placeholder="Enter the password used for encryption" 
                                    value={password}
                                    onChange={(e) => setPassword(e.target.value)}
                                />
                                <button 
                                    type="button" 
                                    className="password-toggle"
                                    onClick={togglePasswordVisibility}
                                >
                                    <i className={showPassword ? "fas fa-eye-slash" : "fas fa-eye"}></i>
                                </button>
                            </div>
                        </div>
                    )}
                    
                    {selectedFile && (
                        <div className="password-input">
                            <label htmlFor="algorithm-select">Encryption Algorithm</label>
                            <select 
                                id="algorithm-select"
                                className="form-control"
                                value={algorithm}
                                onChange={(e) => setAlgorithm(e.target.value)}
                            >
                                <option value="auto">Auto-detect (Recommended)</option>
                                <option value="aes">AES-256-GCM</option>
                                <option value="chacha20">ChaCha20-Poly1305</option>
                            </select>
                            <p style={{ fontSize: '0.9rem', color: 'var(--gray)', marginTop: '0.5rem' }}>
                                <i className="fas fa-info-circle"></i> Use auto-detect for most cases. Only select manually if auto-detection fails.
                            </p>
                        </div>
                    )}
                    
                    <div className="action-buttons">
                        <button className="btn btn-warning btn-large" onClick={handleDecrypt} disabled={isProcessing}>
                            {isProcessing ? 'Decrypting...' : 'Decrypt Files'}
                        </button>
                        <button className="btn btn-outline" onClick={resetForm}>
                            Reset
                        </button>
                    </div>
                    
                    <div className={`progress-section ${isProcessing ? 'active' : ''}`}>
                        <div className="status-message">Decrypting your files... Please wait.</div>
                        <div className="progress-bar">
                            <div className="progress" style={{ width: `${progress}%` }}></div>
                        </div>
                        <div className="status-message">{progress}% Complete</div>
                    </div>
                    
                    <div className={`result-section ${result?.success ? 'success' : ''} ${result?.success === false ? 'error' : ''}`}>
                        <i className={`fas ${result?.success ? 'fa-check-circle' : 'fa-exclamation-circle'}`}></i>
                        <p>{result?.message}</p>
                        {decryptedFiles.length > 0 && (
                            <div style={{ marginTop: '1rem' }}>
                                <h4>Decrypted Files ({decryptedFiles.length}):</h4>
                                {decryptedFiles.map((file, index) => (
                                    <div key={index} style={{ margin: '0.5rem 0' }}>
                                        <a 
                                            href={file.url} 
                                            download={file.name}
                                            className="btn download-btn"
                                            style={{ width: 'auto', padding: '0.5rem 1rem' }}
                                        >
                                            <i className="fas fa-download"></i> Download {file.name}
                                        </a>
                                    </div>
                                ))}
                            </div>
                        )}
                    </div>
                </div>
            </div>
        </div>
    );
};