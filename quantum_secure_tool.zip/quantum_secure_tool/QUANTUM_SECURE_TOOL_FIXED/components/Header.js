const { useState } = React;

const Header = ({ currentPage, setCurrentPage, user, onLogout }) => {
    const [menuOpen, setMenuOpen] = useState(false);
    
    const toggleMenu = () => {
        setMenuOpen(!menuOpen);
    };
    
    const handleLogout = () => {
        onLogout();
        setMenuOpen(false);
    };
    
    return (
        <header>
            <div className="container">
                <div className="header-content">
                    <div className="logo">
                        <i className="fas fa-shield-alt"></i>
                        <span>Secure File Encryption</span>
                    </div>
                    
                    <button className="mobile-menu-btn" onClick={toggleMenu}>
                        <i className="fas fa-bars"></i>
                    </button>
                    
                    <nav>
                        <ul className={menuOpen ? 'active' : ''}>
                            <li><a 
                                href="#" 
                                className={currentPage === 'home' ? 'active' : ''}
                                onClick={(e) => { e.preventDefault(); setCurrentPage('home'); setMenuOpen(false); }}
                            >Home</a></li>
                            <li><a 
                                href="#" 
                                className={currentPage === 'encrypt' ? 'active' : ''}
                                onClick={(e) => { e.preventDefault(); setCurrentPage('encrypt'); setMenuOpen(false); }}
                            >Encrypt</a></li>
                            <li><a 
                                href="#" 
                                className={currentPage === 'decrypt' ? 'active' : ''}
                                onClick={(e) => { e.preventDefault(); setCurrentPage('decrypt'); setMenuOpen(false); }}
                            >Decrypt</a></li>
                            <li><a 
                                href="#" 
                                className={currentPage === 'about' ? 'active' : ''}
                                onClick={(e) => { e.preventDefault(); setCurrentPage('about'); setMenuOpen(false); }}
                            >About</a></li>
                            <li className="user-info">
                                <div className="user-avatar">
                                    {user ? user.charAt(0).toUpperCase() : 'U'}
                                </div>
                                <span>{user}</span>
                                <button 
                                    className="btn btn-outline" 
                                    style={{ padding: '0.3rem 0.8rem', marginLeft: '10px' }}
                                    onClick={handleLogout}
                                >
                                    Logout
                                </button>
                            </li>
                        </ul>
                    </nav>
                </div>
            </div>
        </header>
    );
};