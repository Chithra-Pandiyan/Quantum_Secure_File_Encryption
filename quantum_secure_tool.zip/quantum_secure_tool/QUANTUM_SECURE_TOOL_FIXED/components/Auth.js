const { useState } = React;

const AuthPage = ({ onLogin }) => {
    const [isLogin, setIsLogin] = useState(true);
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    const [confirmPassword, setConfirmPassword] = useState('');
    const [showPassword, setShowPassword] = useState(false);
    const [error, setError] = useState('');

    const handleSubmit = (e) => {
        e.preventDefault();
        setError('');

        // load users from localStorage
        const users = JSON.parse(localStorage.getItem('secureCryptUsers') || '{}');

        if (isLogin) {
            // Login: require existing user and matching hashed password
            if (!username || !password) {
                setError('Please enter both username and password');
                return;
            }

            const user = users[username];
            if (!user) {
                setError('User not found. Please register first.');
                return;
            }

            // hash the entered password and compare
            try {
                const enteredHash = CryptoJS.SHA256(password).toString();
                if (enteredHash === user.passwordHash) {
                    // successful login
                    setError('');
                    onLogin(username);
                } else {
                    setError('Invalid username or password');
                }
            } catch (err) {
                setError('Crypto error. Cannot process login.');
            }

        } else {
            // Registration logic
            if (!username || !password) {
                setError('Please enter both username and password');
                return;
            }

            if (password !== confirmPassword) {
                setError('Passwords do not match');
                return;
            }

            if (password.length < 6) {
                setError('Password must be at least 6 characters long');
                return;
            }

            // prevent duplicate usernames
            if (users[username]) {
                setError('Username already taken. Please choose another username');
                return;
            }

            // hash password before storing
            try {
                const passwordHash = CryptoJS.SHA256(password).toString();
                users[username] = {
                    passwordHash,
                    createdAt: new Date().toISOString()
                };
                localStorage.setItem('secureCryptUsers', JSON.stringify(users));

                setError('');
                alert('Registration successful! Please login.');
                setIsLogin(true);
                setPassword('');
                setConfirmPassword('');
            } catch (err) {
                setError('Crypto error. Cannot complete registration.');
            }
        }
    };

    const togglePasswordVisibility = () => {
        setShowPassword(!showPassword);
    };

    const toggleForm = () => {
        setIsLogin(!isLogin);
        setError('');
        setPassword('');
        setConfirmPassword('');
    };

    return (
        <div className="login-container">
            <div className="login-box">
                <div className="login-logo">
                    <i className="fas fa-shield-alt"></i>
                    <span>Secure File Encryption</span>
                </div>
                
                <form className="login-form" onSubmit={handleSubmit}>
                    <div className="form-group">
                        <label htmlFor="username">Username</label>
                        <input 
                            type="text" 
                            id="username" 
                            className="form-control" 
                            placeholder="Enter your username"
                            value={username}
                            onChange={(e) => setUsername(e.target.value)}
                            required
                        />
                    </div>
                    
                    <div className="form-group">
                        <label htmlFor="password">{isLogin ? 'Password' : 'Create Password'}</label>
                        <div className="password-input-container">
                            <input 
                                type={showPassword ? "text" : "password"} 
                                id="password" 
                                className="form-control" 
                                placeholder={isLogin ? "Enter your password" : "Create a password"}
                                value={password}
                                onChange={(e) => setPassword(e.target.value)}
                                required
                                minLength="6"
                            />
                            <button 
                                type="button" 
                                className="password-toggle"
                                onClick={togglePasswordVisibility}
                            >
                                <i className={showPassword ? "fas fa-eye-slash" : "fas fa-eye"}></i>
                            </button>
                        </div>
                    </div>
                    
                    {!isLogin && (
                        <div className="form-group">
                            <label htmlFor="confirmPassword">Confirm Password</label>
                            <input 
                                type={showPassword ? "text" : "password"} 
                                id="confirmPassword" 
                                className="form-control" 
                                placeholder="Confirm your password"
                                value={confirmPassword}
                                onChange={(e) => setConfirmPassword(e.target.value)}
                                required
                                minLength="6"
                            />
                        </div>
                    )}
                    
                    {error && (
                        <div style={{ color: 'var(--danger)', marginBottom: '1rem', textAlign: 'center' }}>
                            {error}
                        </div>
                    )}
                    
                    <button type="submit" className="btn">
                        {isLogin ? 'Login' : 'Register'}
                    </button>
                </form>
                
                <div className="toggle-form">
                    <p>
                        {isLogin ? "Don't have an account? " : "Already have an account? "}
                        <a href="#" onClick={toggleForm}>
                            {isLogin ? 'Register here' : 'Login here'}
                        </a>
                    </p>
                </div>
            </div>
        </div>
    );
};