const { useState, useEffect } = React;

const EncryptionTool = ({ setCurrentPage }) => {
    const [selectedFiles, setSelectedFiles] = useState([]);
    const [password, setPassword] = useState('');
    const [showPassword, setShowPassword] = useState(false);
    const [isProcessing, setIsProcessing] = useState(false);
    const [progress, setProgress] = useState(0);
    const [result, setResult] = useState(null);
    const [encryptedFileUrl, setEncryptedFileUrl] = useState(null);
    const [algorithm, setAlgorithm] = useState('aes');
    
    const handleFileSelect = (e) => {
        const files = Array.from(e.target.files);
        if (files.length > 0) {
            setSelectedFiles(files);
            setResult(null);
        }
    };
    
    const handleDragOver = (e) => {
        e.preventDefault();
        e.currentTarget.classList.add('dragover');
    };
    
    const handleDragLeave = (e) => {
        e.preventDefault();
        e.currentTarget.classList.remove('dragover');
    };
    
    const handleDrop = (e) => {
        e.preventDefault();
        e.currentTarget.classList.remove('dragover');
        
        const files = Array.from(e.dataTransfer.files);
        if (files.length > 0) {
            setSelectedFiles(files);
            setResult(null);
        }
    };
    
    const handleEncrypt = async () => {
        if (selectedFiles.length === 0) {
            alert('Please select files to encrypt.');
            return;
        }
        
        if (!password) {
            alert('Please enter an encryption password.');
            return;
        }
        
        if (password.length < 6) {
            alert('Password must be at least 6 characters long.');
            return;
        }
        
        setIsProcessing(true);
        setProgress(0);
        setResult(null);
        
        try {
            setProgress(20);
            
            // Validate all files
            for (const file of selectedFiles) {
                CryptoUtils.validateFile(file);
            }
            
            setProgress(40);
            
            // Create encrypted ZIP
            const zipBlob = await CryptoUtils.createEncryptedZip(selectedFiles, password, algorithm);
            
            setProgress(80);
            
            const url = URL.createObjectURL(zipBlob);
            setEncryptedFileUrl(url);
            
            setProgress(100);
            
            setResult({ 
                success: true, 
                message: `Files encrypted successfully using ${algorithm.toUpperCase()}! You can now download the encrypted ZIP file.` 
            });
            
        } catch (error) {
            console.error('Encryption error:', error);
            setResult({ 
                success: false, 
                message: `Encryption failed: ${error.message}` 
            });
        } finally {
            setIsProcessing(false);
        }
    };
    
    const resetForm = () => {
        setSelectedFiles([]);
        setPassword('');
        setResult(null);
        setEncryptedFileUrl(null);
        document.getElementById('file-input').value = '';
    };
    
    const togglePasswordVisibility = () => {
        setShowPassword(!showPassword);
    };
    
    const handleAlgorithmChange = (algo) => {
        setAlgorithm(algo);
    };
    
    const generatePassword = () => {
        setPassword(CryptoUtils.generateSecurePassword());
    };

    return (
        <div className="page active">
            <div className="container">
                <div className="tool-section">
                    <h2><i className="fas fa-lock"></i> Encrypt Your Files</h2>
                    
                    <div className="algorithm-selection">
                        <label>Select Encryption Algorithm</label>
                        <div className="algorithm-options">
                            <div 
                                className={`algorithm-option ${algorithm === 'aes' ? 'selected' : ''}`}
                                onClick={() => handleAlgorithmChange('aes')}
                            >
                                <span className="algorithm-badge">NIST Standard</span>
                                <h4>AES-256-GCM</h4>
                                <p>Advanced Encryption Standard with authentication</p>
                            </div>
                            <div 
                                className={`algorithm-option ${algorithm === 'chacha20' ? 'selected' : ''}`}
                                onClick={() => handleAlgorithmChange('chacha20')}
                            >
                                <span className="algorithm-badge">High Performance</span>
                                <h4>ChaCha20-Poly1305</h4>
                                <p>Modern stream cipher with authentication</p>
                            </div>
                        </div>
                    </div>
                    
                    <div 
                        className="file-upload-area"
                        onDragOver={handleDragOver}
                        onDragLeave={handleDragLeave}
                        onDrop={handleDrop}
                        onClick={() => document.getElementById('file-input').click()}
                    >
                        <i className="fas fa-cloud-upload-alt"></i>
                        <h3>Drag & Drop your files here</h3>
                        <p>or click to browse (multiple files supported)</p>
                        <input 
                            type="file" 
                            id="file-input" 
                            style={{ display: 'none' }} 
                            onChange={handleFileSelect}
                            multiple
                        />
                    </div>
                    
                    <div className={`file-info ${selectedFiles.length > 0 ? 'active' : ''}`}>
                        <h4>Selected Files ({selectedFiles.length}):</h4>
                        {selectedFiles.map((file, index) => (
                            <p key={index}><i className="fas fa-file"></i> {file.name} ({(file.size / 1024 / 1024).toFixed(2)} MB)</p>
                        ))}
                    </div>
                    
                    <div className="password-input">
                        <label htmlFor="encrypt-password">
                            Encryption Password
                            <button 
                                type="button" 
                                className="btn btn-outline" 
                                style={{ padding: '0.3rem 0.5rem', marginLeft: '10px', fontSize: '0.8rem' }}
                                onClick={generatePassword}
                            >
                                Generate Secure
                            </button>
                        </label>
                        <div className="password-input-container">
                            <input 
                                type={showPassword ? "text" : "password"} 
                                id="encrypt-password" 
                                className="form-control" 
                                placeholder="Enter a strong password (min 6 characters)" 
                                value={password}
                                onChange={(e) => setPassword(e.target.value)}
                                minLength="6"
                            />
                            <button 
                                type="button" 
                                className="password-toggle"
                                onClick={togglePasswordVisibility}
                            >
                                <i className={showPassword ? "fas fa-eye-slash" : "fas fa-eye"}></i>
                            </button>
                        </div>
                        <p style={{ fontSize: '0.9rem', color: 'var(--gray)', marginTop: '0.5rem' }}>
                            <i className="fas fa-info-circle"></i> Remember this password! You'll need it to decrypt the files.
                        </p>
                    </div>
                    
                    <div className="action-buttons">
                        <button className="btn btn-success btn-large" onClick={handleEncrypt} disabled={isProcessing}>
                            {isProcessing ? 'Encrypting...' : `Encrypt ${selectedFiles.length > 1 ? 'Files' : 'File'}`}
                        </button>
                        <button className="btn btn-outline" onClick={resetForm}>
                            Reset
                        </button>
                    </div>
                    
                    <div className={`progress-section ${isProcessing ? 'active' : ''}`}>
                        <div className="status-message">Encrypting your files... Please wait.</div>
                        <div className="progress-bar">
                            <div className="progress" style={{ width: `${progress}%` }}></div>
                        </div>
                        <div className="status-message">{progress}% Complete</div>
                    </div>
                    
                    <div className={`result-section ${result?.success ? 'success' : ''} ${result?.success === false ? 'error' : ''}`}>
                        <i className={`fas ${result?.success ? 'fa-check-circle' : 'fa-exclamation-circle'}`}></i>
                        <p>{result?.message}</p>
                        {result?.success && encryptedFileUrl && (
                            <a 
                                href={encryptedFileUrl} 
                                download={`encrypted_files_${new Date().getTime()}.zip`}
                                className="btn download-btn"
                            >
                                <i className="fas fa-download"></i> Download Encrypted ZIP
                            </a>
                        )}
                    </div>
                </div>
            </div>
        </div>
    );
};