const AboutPage = ({ setCurrentPage }) => {
    return (
        <div className="page active">
            <div className="container">
                <div className="about-content">
                    <h2>About Secure File Encryption Tool</h2>
                    <p>
                        Our Secure File Encryption Tool utilizes modern cryptographic algorithms to protect your sensitive data. 
                        All encryption and decryption happens locally in your browser, ensuring your files never leave your device unencrypted.
                    </p>
                    
                    <h3>Algorithms We Use</h3>
                    <p>
                        <strong>AES-256-GCM:</strong> The Advanced Encryption Standard with 256-bit keys in Galois/Counter Mode. 
                        This is the same encryption standard used by governments and security experts worldwide, providing both 
                        confidentiality and authentication.
                    </p>
                    <p>
                        <strong>ChaCha20-Poly1305:</strong> A modern stream cipher with authentication that provides superior 
                        performance on many platforms while maintaining strong security guarantees.
                    </p>
                    
                    <div className="faq-section">
                        <h3>Frequently Asked Questions</h3>
                        
                        <div className="faq-item">
                            <h3>Is my data secure?</h3>
                            <p>
                                Absolutely. We use industry-standard encryption algorithms that are considered secure by 
                                cryptographic experts worldwide. Your files are encrypted locally in your browser and 
                                never leave your device without being encrypted first.
                            </p>
                        </div>
                        
                        <div className="faq-item">
                            <h3>What types of files can I encrypt?</h3>
                            <p>
                                You can encrypt any type of file - documents, images, videos, archives, and more. 
                                There are no restrictions on file types, though we recommend keeping individual files under 100MB for performance.
                            </p>
                        </div>
                        
                        <div className="faq-item">
                            <h3>What happens if I forget my password?</h3>
                            <p>
                                We don't store your passwords, so if you forget your encryption password, there is no way 
                                to recover your files. Please make sure to store your password securely using a password manager.
                            </p>
                        </div>
                        
                        <div className="faq-item">
                            <h3>Is this tool free to use?</h3>
                            <p>
                                Yes, our Secure File Encryption Tool is completely free to use with no hidden costs or limitations.
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};